
importScripts('https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/10.10.0/firebase-messaging.js');

firebase.initializeApp({
    apiKey: "AIzaSyDekVhENUNb46T2e5TZIZ8JoiRWmacz0nA",
    authDomain: "peladaoapp.firebaseapp.com",
    projectId: "peladaoapp",
    storageBucket: "peladaoapp.firebasestorage.app",
    messagingSenderId: "391495258510",
    appId: "1:391495258510:web:7f22b09f492ad8086354df"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
    console.log('Mensagem recebida em background: ', payload);
    const notificationTitle = payload.notification.title;
    const notificationOptions = {
        body: payload.notification.body
    };
    self.registration.showNotification(notificationTitle, notificationOptions);
});
